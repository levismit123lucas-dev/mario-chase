# Super Hide & Chase V2 — Nintendo DS / DS Lite

An original Nintendo DS homebrew prototype built with libnds.

## Version 2 features
- DS 3D-engine polygon geometry: raised arena walls and simple low-poly toy characters.
- Three arena layouts: Mushroom Village, Ghost Mansion, Toy Castle.
- One player versus three hunter bots.
- Grid-based breadth-first pathfinding so bots follow corridors.
- 120-second survival round, star pickups, score, dash, hide, radar and pause.
- D-pad and face-button controls; lower-screen text HUD.

## Controls
- D-pad: move
- A: dash
- B: hide briefly
- X: radar pulse
- START: pause / resume
- Title screen: LEFT/RIGHT choose map, A/START play
- End screen: A returns to menu

## Build a .nds ROM
This source requires devkitPro with devkitARM and libnds installed.

1. Open the devkitPro MSYS2 terminal.
2. Change directory to this project folder.
3. Run `make`.
4. The output should be `SuperHideChase_V2.nds`.

The current ChatGPT runtime does not include the devkitARM compiler, so this package contains the source project rather than a compiled ROM.

## Important prototype notes
- The DS top screen renders polygon geometry using the DS 3D engine, with a fixed isometric-style camera.
- Character models are intentionally simple low-poly shapes. There are no external model or sound assets yet.
- Bot pathfinding uses a compact grid distance field and is suitable for this small DS arena.
- This is an original fan-made homebrew concept and is not affiliated with Nintendo.
