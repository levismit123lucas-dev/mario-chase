#!/bin/sh
# Bouwt SuperHideChase_V2.nds via Docker (geen devkitPro-installatie nodig)
docker run --rm -v "$PWD":/project -w /project devkitpro/devkitarm make
