@echo off
docker run --rm -v "%cd%":/project -w /project devkitpro/devkitarm make
pause
