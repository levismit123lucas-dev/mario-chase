#include <nds.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAP_W 16
#define MAP_H 12
#define TILE 16
#define BOT_COUNT 3
#define STAR_COUNT 8
#define F16(n) ((v16)((n) * 4096))

typedef struct { int x, z, alive; } Actor;
typedef struct { int x, z, active; } Pickup;

static const unsigned char world[3][MAP_H][MAP_W] = {
{
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
{1,0,1,1,0,0,1,1,1,0,0,1,1,0,0,1},
{1,0,1,0,0,0,0,0,1,0,0,0,1,0,0,1},
{1,0,1,0,1,1,0,0,1,1,0,0,1,0,0,1},
{1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1},
{1,0,1,0,1,0,1,1,1,0,1,1,0,1,0,1},
{1,0,1,0,0,0,0,0,0,0,0,1,0,1,0,1},
{1,0,1,1,1,0,1,1,0,1,0,1,0,0,0,1},
{1,0,0,0,0,0,0,1,0,0,0,0,0,1,0,1},
{1,0,0,1,1,0,0,0,0,1,1,0,0,0,0,1},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
},
{
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{1,0,0,0,1,0,0,0,0,0,1,0,0,0,0,1},
{1,0,1,0,1,0,1,1,1,0,1,0,1,1,0,1},
{1,0,1,0,0,0,0,0,1,0,0,0,0,1,0,1},
{1,0,1,1,1,1,1,0,1,1,1,1,0,1,0,1},
{1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,1},
{1,1,1,1,1,0,1,1,1,1,0,1,1,1,0,1},
{1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1},
{1,0,1,1,1,1,1,1,0,1,1,1,1,1,0,1},
{1,0,0,0,0,0,0,1,0,0,0,0,0,1,0,1},
{1,0,1,1,0,1,0,0,0,1,1,0,0,0,0,1},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
},
{
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
{1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1},
{1,0,1,1,0,1,0,1,1,0,1,0,1,1,0,1},
{1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,1},
{1,1,1,0,1,1,1,0,1,1,1,1,0,1,0,1},
{1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,1},
{1,0,1,1,1,0,1,1,1,1,0,1,1,1,0,1},
{1,0,0,0,1,0,0,0,0,1,0,0,0,0,0,1},
{1,1,1,0,1,1,1,0,1,1,1,1,1,1,0,1},
{1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1},
{1,0,1,1,0,1,1,0,1,1,0,1,0,0,0,1},
{1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1}
}
};

static Actor player, bots[BOT_COUNT];
static Pickup stars[STAR_COUNT];
static int mapIndex=0, state=0, timerFrames=7200, score=0;
static int dashFrames=0, hideFrames=0, radarFrames=0;
static int tick=0, caught=0, rng=0x13579;

static int randomN(int n) {
    rng = rng * 1103515245 + 12345;
    return ((unsigned)(rng >> 8) & 0x7fffffff) % n;
}
static int isWall(int x, int z) {
    int tx=x/TILE, tz=z/TILE;
    if(tx<0 || tz<0 || tx>=MAP_W || tz>=MAP_H) return 1;
    return world[mapIndex][tz][tx] != 0;
}
static int canStand(int x,int z) {
    return !isWall(x-4,z-4) && !isWall(x+4,z-4) &&
           !isWall(x-4,z+4) && !isWall(x+4,z+4);
}
static void moveActor(Actor *a,int dx,int dz) {
    if(canStand(a->x+dx,a->z)) a->x+=dx;
    if(canStand(a->x,a->z+dz)) a->z+=dz;
}
static void putVertex(int x,int y,int z) {
    glVertex3v16(F16(x),F16(y),F16(z));
}
static void quad(int x1,int y1,int z1,int x2,int y2,int z2,
                 int x3,int y3,int z3,int x4,int y4,int z4) {
    putVertex(x1,y1,z1); putVertex(x2,y2,z2);
    putVertex(x3,y3,z3); putVertex(x4,y4,z4);
}
static void cube(int x,int y,int z,int w,int h,int d,int r,int g,int b) {
    int x2=x+w, y2=y+h, z2=z+d;
    glBegin(GL_QUADS);
    glColor3b(r,g,b);
    quad(x,y,z2,x2,y,z2,x2,y2,z2,x,y2,z2);
    glColor3b(r-8,g-8,b-8);
    quad(x2,y,z,x,y,z,x,y2,z,x2,y2,z);
    glColor3b(r-15,g-15,b-15);
    quad(x,y,z,x,y,z2,x,y2,z2,x,y2,z);
    glColor3b(r-4,g-4,b-4);
    quad(x2,y,z2,x2,y,z,x2,y2,z,x2,y2,z2);
    glColor3b(r+5,g+5,b+5);
    quad(x,y2,z2,x2,y2,z2,x2,y2,z,x,y2,z);
    glColor3b(r-18,g-18,b-18);
    quad(x,y,z,x2,y,z,x2,y,z2,x,y,z2);
    glEnd();
}
static void floorTile(int x,int z,int r,int g,int b) {
    glBegin(GL_QUADS); glColor3b(r,g,b);
    quad(x,0,z,x+TILE,0,z,x+TILE,0,z+TILE,x,0,z+TILE);
    glEnd();
}
static void drawCharacter(Actor *a,int r,int g,int b,int runner) {
    // Small low-poly toy character: boots, body, head and cap.
    cube(a->x-5,0,a->z-4,4,5,8,35,30,30);
    cube(a->x+1,0,a->z-4,4,5,8,35,30,30);
    cube(a->x-6,5,a->z-5,12,10,10,r,g,b);
    cube(a->x-5,15,a->z-4,10,9,8,105,82,60);
    cube(a->x-6,23,a->z-5,12,3,10,runner?120:35,runner?105:105,runner?20:115);
    cube(a->x-3,19,a->z+3,2,2,1,8,8,8);
    cube(a->x+1,19,a->z+3,2,2,1,8,8,8);
}
static void drawStar( int x,int z) {
    // Gold collectible represented by a bright faceted crystal.
    cube(x-3,5,z-3,6,6,6,120,110,20);
    cube(x-1,11,z-1,2,3,2,127,125,70);
}
static void drawArena(void) {
    for(int z=0;z<MAP_H;z++) for(int x=0;x<MAP_W;x++) {
        int px=x*TILE, pz=z*TILE;
        if(world[mapIndex][z][x]) {
            floorTile(px,pz,35,55,80);
            cube(px,0,pz,TILE,19,TILE,65,85,115);
            cube(px+1,19,pz+1,TILE-2,2,TILE-2,95,112,127);
        } else {
            floorTile(px,pz, (x+z)%2?38:45, (x+z)%2?92:105, (x+z)%2?43:52);
        }
    }
    for(int i=0;i<STAR_COUNT;i++) if(stars[i].active) drawStar(stars[i].x,stars[i].z);
    for(int i=0;i<BOT_COUNT;i++) if(bots[i].alive) drawCharacter(&bots[i],110,42,48,0);
    if(hideFrames==0) drawCharacter(&player,45,75,120,1);
}
static void spawnStars(void) {
    for(int i=0;i<STAR_COUNT;i++) {
        int x,z,tries=0;
        do { x=24+randomN(208); z=24+randomN(144); tries++; }
        while(isWall(x,z) && tries<200);
        stars[i]=(Pickup){x,z,1};
    }
}
static void startGame(void) {
    player=(Actor){24,24,1};
    bots[0]=(Actor){224,24,1}; bots[1]=(Actor){224,160,1}; bots[2]=(Actor){24,160,1};
    timerFrames=7200; score=0; caught=0; dashFrames=hideFrames=radarFrames=0; tick=0;
    spawnStars(); state=1;
}

/* Breadth-first distance field from the player tile. Each hunter follows
   a shortest corridor route rather than walking directly into walls. */
static int distMap[MAP_H][MAP_W];
static void buildDistanceField(void) {
    int qx[MAP_W*MAP_H], qz[MAP_W*MAP_H], head=0, tail=0;
    for(int z=0;z<MAP_H;z++) for(int x=0;x<MAP_W;x++) distMap[z][x]=999;
    int sx=player.x/TILE, sz=player.z/TILE;
    if(sx<0||sz<0||sx>=MAP_W||sz>=MAP_H) return;
    distMap[sz][sx]=0; qx[tail]=sx; qz[tail++]=sz;
    const int ox[4]={1,-1,0,0}, oz[4]={0,0,1,-1};
    while(head<tail) {
        int x=qx[head], z=qz[head++], d=distMap[z][x]+1;
        for(int k=0;k<4;k++) {
            int nx=x+ox[k], nz=z+oz[k];
            if(nx<0||nz<0||nx>=MAP_W||nz>=MAP_H) continue;
            if(world[mapIndex][nz][nx] || distMap[nz][nx]!=999) continue;
            distMap[nz][nx]=d; qx[tail]=nx; qz[tail++]=nz;
        }
    }
}
static void updateBots(void) {
    if(tick%8==0) buildDistanceField();
    const int ox[4]={1,-1,0,0}, oz[4]={0,0,1,-1};
    for(int i=0;i<BOT_COUNT;i++) {
        Actor *b=&bots[i]; if(!b->alive) continue;
        int tx=b->x/TILE, tz=b->z/TILE, best=distMap[tz][tx], bx=tx, bz=tz;
        for(int k=0;k<4;k++) {
            int nx=tx+ox[k], nz=tz+oz[k];
            if(nx<0||nz<0||nx>=MAP_W||nz>=MAP_H||world[mapIndex][nz][nx]) continue;
            if(distMap[nz][nx]<best) { best=distMap[nz][nx]; bx=nx; bz=nz; }
        }
        int targetX=bx*TILE+TILE/2, targetZ=bz*TILE+TILE/2;
        int dx=(targetX>b->x)?1:(targetX<b->x?-1:0);
        int dz=(targetZ>b->z)?1:(targetZ<b->z?-1:0);
        int speed=(i==1)?2:1;
        if(randomN(90)==0) { dx=0; dz=0; } // short thinking pause
        moveActor(b,dx*speed,dz*speed);
        int cx=player.x-b->x, cz=player.z-b->z;
        if(cx*cx+cz*cz<150 && hideFrames==0) caught=1;
    }
}
static void update(void) {
    scanKeys(); int held=keysHeld(), down=keysDown();
    if(state==0) {
        if(down&KEY_LEFT) mapIndex=(mapIndex+2)%3;
        if(down&KEY_RIGHT) mapIndex=(mapIndex+1)%3;
        if(down&(KEY_A|KEY_START)) startGame();
        return;
    }
    if(state==2) {
        if(down&KEY_A) state=1;
        if(down&KEY_B) state=0;
        return;
    }
    if(state==3 || state==4) { if(down&KEY_A) state=0; return; }
    if(down&KEY_START) { state=2; return; }

    int dx=0,dz=0;
    if(held&KEY_LEFT) dx=-1; if(held&KEY_RIGHT) dx=1;
    if(held&KEY_UP) dz=-1; if(held&KEY_DOWN) dz=1;
    int speed=dashFrames>0?3:2;
    moveActor(&player,dx*speed,dz*speed);
    if((down&KEY_A) && dashFrames==0) dashFrames=42;
    if((down&KEY_B) && hideFrames==0) hideFrames=55;
    if((down&KEY_X)) radarFrames=90;
    if(dashFrames>0) dashFrames--;
    if(hideFrames>0) hideFrames--;
    if(radarFrames>0) radarFrames--;

    for(int i=0;i<STAR_COUNT;i++) if(stars[i].active) {
        int x=player.x-stars[i].x,z=player.z-stars[i].z;
        if(x*x+z*z<110) { stars[i].active=0; score+=10; }
    }
    updateBots();
    if(caught) { state=3; return; }
    if(timerFrames>0) timerFrames--;
    if(timerFrames==0) state=4;
    tick++;
}
static void hud(void) {
    consoleClear();
    iprintf(" SUPER HIDE & CHASE V2\n");
    if(state==0) {
        iprintf("\n 3D DS HOME-BREW\n\n");
        iprintf(" LEFT/RIGHT: SELECT MAP\n");
        iprintf(" A / START: PLAY\n\n");
        iprintf(" MAP %d: %s\n",mapIndex+1,
            mapIndex==0?"MUSHROOM VILLAGE":mapIndex==1?"GHOST MANSION":"TOY CASTLE");
        iprintf("\n RUNNER vs 3 HUNTERS\n");
        iprintf(" SURVIVE 120 SECONDS!\n");
        return;
    }
    if(state==2) { iprintf("\n      PAUSED\n\n A: RESUME\n B: MENU"); return; }
    if(state==3) { iprintf("\n     CAUGHT!\n\n SCORE: %d\n\n A: MENU",score); return; }
    if(state==4) { iprintf("\n   YOU ESCAPED!\n\n SCORE: %d\n\n A: MENU",score); return; }
    iprintf(" TIME: %02d:%02d   SCORE: %d\n",timerFrames/3600,(timerFrames/60)%60,score);
    iprintf(" MAP %d   HUNTERS: 3\n\n",mapIndex+1);
    iprintf(" D-PAD: MOVE\n A: DASH  B: HIDE\n X: RADAR\n START: PAUSE\n");
    if(radarFrames>0) iprintf("\n RADAR PULSE ACTIVE!");
    else iprintf("\n COLLECT GOLD STARS!");
}
static void render3D(void) {
    glMatrixMode(GL_PROJECTION); glLoadIdentity();
    glOrthof32(-140*4096,140*4096,-110*4096,110*4096,-300*4096,300*4096);
    glMatrixMode(GL_MODELVIEW); glLoadIdentity();
    glRotatef32(55*4096,4096,0,0);
    glTranslatef32(-128*4096,0,-96*4096);
    glClearColor(25,45,75,31);
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
    glPolyFmt(POLY_ALPHA(31)|POLY_CULL_NONE|POLY_FORMAT_LIGHT0);
    if(state==0) {
        cube(75,0,55,106,18,80,60,105,120);
        cube(95,18,72,66,26,45,100,70,65);
        cube(112,44,84,32,22,22,115,105,55);
        cube(105,66,78,46,5,35,120,110,35);
    } else {
        drawArena();
        if(radarFrames>0) {
            for(int i=0;i<BOT_COUNT;i++)
                cube(bots[i].x-7,1,bots[i].z-7,14,2,14,120,115,25);
        }
    }
}
int main(void) {
    videoSetMode(MODE_0_3D);
    videoSetModeSub(MODE_0_2D);
    vramSetBankA(VRAM_A_TEXTURE);
    vramSetBankC(VRAM_C_SUB_BG);
    consoleDemoInit();
    glInit();
    glEnable(GL_ANTIALIAS);
    glEnable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
    glViewport(0,0,255,191);
    glClearDepth(0x7FFF);
    while(1) {
        update();
        render3D();
        hud();
        glFlush(0);
        swiWaitForVBlank();
    }
    return 0;
}
